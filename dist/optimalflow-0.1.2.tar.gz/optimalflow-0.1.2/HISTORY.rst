=======
History
=======

0.1.2 (2020-08-14)
------------------

* Add *fastClassifier*, and *fastRegressor* class which are both random parameter search based
* Modify the display settings when using dynaClassifier in non in_pipeline mode

0.1.1 (2020-08-10)
------------------

* Add classifiers: LinearSVC, HistGradientBoostingClassifier, SGDClassifier, RidgeClassifierCV.
* Modify Readme.md file.

0.1.0 (2020-08-10)
------------------

* First release on PyPI.