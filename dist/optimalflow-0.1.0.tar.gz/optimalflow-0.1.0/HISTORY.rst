=======
History
=======

0.1.0 (2020-08-10)
------------------

* First release on PyPI.